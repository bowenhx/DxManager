//
//  NSWebImg+NSString.h
//  DxManager
//
//  Created by Stray on 16/10/1.
//  Copyright © 2016年 XXTechnology Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Image_URL)

- (void)img_setImageWithURL:(NSString *)string placeholderImage:(UIImage *)img;
@end
