//
//  CustomBarButtonItem.h
//  EduKingdom
//
//  Created by ligb on 16/7/7.
//  Copyright © 2016年 com.mobile-kingdom.ekapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomBarButtonItem : UIBarButtonItem

//+ (void)itemViewSegmentedControl:(NSArray *)title;

+ (NSArray <UIBarButtonItem *>*)rightItemAddButton:(NSArray *)imgs;

@end
