//
//  UIButton+EXCell.h
//  BKMobile
//
//  Created by Guibin on 15/2/6.
//  Copyright (c) 2015年 com.mobile-kingdom.bkapps All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton_EXCell : UIButton

@property (nonatomic , assign) NSInteger cId;   //button 的标记扩展
@property (nonatomic , assign) NSInteger fid;   //

@property (nonatomic , assign) NSInteger section;
@property (nonatomic , assign) NSInteger row;


@end
