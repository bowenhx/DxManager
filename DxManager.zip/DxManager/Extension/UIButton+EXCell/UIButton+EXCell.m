//
//  UIButton+EXCell.m
//  BKMobile
//
//  Created by Guibin on 15/2/6.
//  Copyright (c) 2015年 com.mobile-kingdom.bkapps All rights reserved.
//

#import "UIButton+EXCell.h"

@implementation UIButton_EXCell


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
