//
//  CustomImageView.h
//  DxManager
//
//  Created by ligb on 16/10/17.
//  Copyright © 2016年 XXTechnology Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomImageView : UIView

@property (nonatomic , strong) NSArray *imgItems;


@end
