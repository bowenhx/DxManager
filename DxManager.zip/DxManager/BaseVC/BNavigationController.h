//
//  BNavigationController.h
//  BKMobile
//
//  Created by ligb on 15/2/4.
//  Copyright (c) 2015年 com.mobile-kingdom.bkapps All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNavigationController : UINavigationController

@end
