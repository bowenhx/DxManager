
#ifndef EKURL_h
#define EKURL_h



#endif /* EKURL_h */
//所有的 url 宏

// API host url
#define BASE_URL @"http://dx.sitemn.com/Ser/Managers.ashx"

//图片 根地址
#define BASE_IMG_URL  @"http://dx.sitemn.com"


//首页第一个数据列表，“通知”
#define API_Home_News @"?action=getNewsList&aid=52"

//登陆
#define API_Login  @"?action=doLogin"//&username=manager&password=admin888


