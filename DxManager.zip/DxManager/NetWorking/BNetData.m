//
//  BNetData.m
//  BKMobile
//
//  Created by ligb on 16/5/20.
//  Copyright © 2016年 com.mobile-kingdom.bkapps. All rights reserved.
//

#import "BNetData.h"

@implementation BNetData

- (void)setValue:(id)value forKey:(NSString *)key{
    [super setValue:value forKey:key];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
