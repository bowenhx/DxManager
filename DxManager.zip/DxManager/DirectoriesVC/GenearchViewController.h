//
//  GenearchViewController.h
//  DxManager
//
//  Created by ligb on 16/10/9.
//  Copyright © 2016年 XXTechnology Co.,Ltd. All rights reserved.
//
//家长通讯录
#import "BaseViewController.h"

@interface GenearchViewController : BaseViewController

@end
