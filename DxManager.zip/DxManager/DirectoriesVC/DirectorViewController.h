//
//  DirectorViewController.h
//  DxManager
//
//  Created by ligb on 16/9/5.
//  Copyright © 2016年 XXTechnology Co.,Ltd. All rights reserved.
//

#import "BaseViewController.h"

@interface DirectorViewController : BaseViewController

@end
