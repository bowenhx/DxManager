//
//  CheckTableViewCell.h
//  DxManager
//
//  Created by ligb on 16/9/21.
//  Copyright © 2016年 XXTechnology Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *classesName;

@property (weak, nonatomic) IBOutlet UILabel *peopleNum1;


@property (weak, nonatomic) IBOutlet UILabel *peopleNum2;


@property (weak, nonatomic) IBOutlet UILabel *peopleNum3;






@end
