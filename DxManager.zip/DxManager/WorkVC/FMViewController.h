//
//  FMViewController.h
//  DxManager
//
//  Created by ligb on 16/10/17.
//  Copyright © 2016年 XXTechnology Co.,Ltd. All rights reserved.
//

#import "BaseViewController.h"

@interface FMViewController : BaseViewController

@end
